﻿Console.Title = "Temperature Converter"; Console.WriteLine("Welcome to Temperature Converter!");
Console.Write("Enter a value in Fahrenheit: ");
int input = Convert.ToInt32(Console.ReadLine());

float result = (input - 32) / 1.8f;

Console.WriteLine(result + "C");
Console.ReadKey();