﻿Console.Title = "Download Remainder";

Console.WriteLine("Welcome to Download Remainder!\n" +
    "This program checks how much data left you have to download for that particular file." +
    "\nUseful for big downloads." +
    "\nType 1 for MB (Megabytes) Type 2 for GB (Gigabytes)\n");

int MBorGB;

try
{
    Console.Write("Your number: ");
    MBorGB = int.Parse(Console.ReadLine());
    if (MBorGB == 1)
    {
        CalculateInMB();
    }
    else if (MBorGB == 2)
    {
        CalculateInGB();
    }
    else
    {
        Console.WriteLine("Invalid number");
    }
}
catch (Exception e)
{
    Console.WriteLine(e.Message);
}



void CalculateInMB()
{
    Console.Write("File Size: ");
    float fileSize = float.Parse(Console.ReadLine());

    Console.Write("File data downloaded: ");
    float fileDownloadedData = float.Parse(Console.ReadLine());

    if (fileSize < fileDownloadedData)
    {
        Console.WriteLine("File size bigger than downloaded data. How is that even possible?");
    }
    if (fileSize == fileDownloadedData)
    {
        Console.WriteLine("File size equal to downloaded data. You probably already downloaded it.");
    }
    else
    {
        float remainder;
        remainder = fileSize - fileDownloadedData;
        Console.WriteLine("You have " + remainder + "MB left to download.");
    }
}
void CalculateInGB()
{
    Console.Write("File Size: ");
    float fileSize = float.Parse(Console.ReadLine());

    Console.Write("File data downloaded: ");
    float fileDownloadedData = float.Parse(Console.ReadLine());

    if (fileSize < fileDownloadedData)
    {
        Console.WriteLine("File size bigger than downloaded data. How is that even possible?");
    }
    if (fileSize == fileDownloadedData)
    {
        Console.WriteLine("File size equal to downloaded data. You probably already downloaded it.");
    }
    else
    {
        float remainder;
        remainder = fileSize - fileDownloadedData;
        Console.WriteLine("You have " + remainder + "GB left to download.");
    }
}

Console.WriteLine("\nPress any key to exit...");
Console.ReadKey();